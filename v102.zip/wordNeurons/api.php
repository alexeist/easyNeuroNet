<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

$bdDir = __DIR__ . '/bd/';
$weightsFile = __DIR__ . '/weights.json';
$trainingDataFile = __DIR__ . '/bd/training_data.txt';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Чтение файлов свойств
    $properties = [];
    if (is_dir($bdDir)) {
        $files = scandir($bdDir);
        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'txt' && $file !== 'training_data.txt') {
                $propertyName = pathinfo($file, PATHINFO_FILENAME);
                $lines = file($bdDir . $file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                $properties[$propertyName] = array_map('trim', $lines);
            }
        }
    }

    // Чтение обучающих данных
    $trainingData = [];
    if (file_exists($trainingDataFile)) {
        $lines = file($trainingDataFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            [$sentence, $target] = explode('|', trim($line), 2);
            $trainingData[] = [
                'sentence' => trim($sentence),
                'target' => [(float)trim($target)] // Преобразуем в массив с числом
            ];
        }
    }

    // Чтение сохранённых весов
    $response = [
        'properties' => $properties,
        'trainingData' => $trainingData
    ];
    if (file_exists($weightsFile)) {
        $response['weights'] = json_decode(file_get_contents($weightsFile), true);
    }

    echo json_encode($response, JSON_PRETTY_PRINT);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Сохранение весов
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    if (isset($data['weights'])) {
        file_put_contents($weightsFile, json_encode($data['weights'], JSON_PRETTY_PRINT));
        echo json_encode(['status' => 'Weights saved successfully']);
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'No weights provided']);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
?>